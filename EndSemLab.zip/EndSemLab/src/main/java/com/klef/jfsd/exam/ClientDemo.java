package com.klef.jfsd.exam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientDemo {
    public static void main(String[] args) {
        // Load the Spring Configuration
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Fetch and Display Employee Bean
        Employee employee = (Employee) context.getBean("employee");
        System.out.println("Employee Details:");
        System.out.println(employee);

        // Fetch and Display Course Bean
        Course course = (Course) context.getBean("course");
        System.out.println("\nCourse Details:");
        System.out.println(course);
    }
}
